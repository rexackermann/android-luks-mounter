#!/system/bin/sh
# ⚡ Android LUKS Mounter Action Script
# This runs when you press the "Action" button in KernelSU/APatch.

/system/bin/mounter --auto-update-config
